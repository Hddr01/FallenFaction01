namespace FallenFaction.Server.DTOs.Auth
{
    public class AuthResponseDto
    {
        public bool Success { get; set; }
        public string? Message { get; set; }
        public string? Token { get; set; }
        public DateTime? TokenExpiration { get; set; }
        public UserDto? User { get; set; }
        public List<string> Errors { get; set; } = new List<string>();

        public bool RequiresTermsAcceptance { get; set; }
        public string? TermsVersion { get; set; }
    }
}